import sys
import os

# 将项目根目录（D:\codes\torchms）添加到 Python 搜索路径
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, project_root)

import pytest
import torch
import mindspore as ms
import numpy as np
from torchax import (
    t2ms, ms2t, t2ms_dtype, ms2t_dtype,
    TORCH_DTYPE_TO_MINDSPORE, MINDSPORE_DTYPE_TO_TORCH,
    NUMPY_UNSUPPORTED_DTYPES
)

# 初始化 MindSpore 上下文（适配 CPU 环境，可根据实际硬件调整）
ms.set_context(mode=ms.PYNATIVE_MODE, device_target="CPU")

# 测试常见 dtype 映射关系
COMMON_DTYPE_PAIRS = [
    (torch.bool, ms.bool_),
    (torch.int8, ms.int8),
    (torch.int16, ms.int16),
    (torch.int32, ms.int32),
    (torch.int64, ms.int64),
    (torch.long, ms.int64),
    (torch.uint8, ms.uint8),
    (torch.float16, ms.float16),
    (torch.half, ms.float16),
    (torch.float32, ms.float32),
    (torch.float64, ms.float64),
    (torch.double, ms.float64),
    (torch.complex64, ms.complex64),
    (torch.complex128, ms.complex128),
]

# 测试 NumPy 不支持的特殊 dtype
UNSUPPORTED_DTYPE_PAIRS = [
    (torch.bfloat16, ms.bfloat16),
    (torch.float8_e4m3fn, ms.float8_e4m3fn),
    (torch.float8_e5m2, ms.float8_e5m2),
]

# 测试不精确映射的 dtype（MindSpore 特有类型）
IMPRECISE_DTYPE_PAIRS = [
    (ms.int4, torch.int8),
    (ms.uint4, torch.uint8),
]

def test_dtype_mapping_consistency():
    """测试 TORCH_DTYPE_TO_MINDSPORE 与 MINDSPORE_DTYPE_TO_TORCH 映射一致性"""
    for torch_dtype, ms_dtype in TORCH_DTYPE_TO_MINDSPORE.items():
        if torch_dtype is None or ms_dtype is None:
            assert MINDSPORE_DTYPE_TO_TORCH.get(ms_dtype) == torch_dtype
            continue
        # 处理 MindSpore dtype 的 .dtype 属性
        ms_key = ms_dtype if isinstance(ms_dtype, ms.dtype) else ms_dtype.dtype
        assert MINDSPORE_DTYPE_TO_TORCH[ms_key] == torch_dtype

def test_t2ms_dtype_function():
    """测试 t2ms_dtype 函数的 dtype 转换正确性"""
    for torch_dtype, ms_dtype in COMMON_DTYPE_PAIRS:
        result = t2ms_dtype(torch_dtype)
        # 统一比较 dtype 对象（处理 .dtype 属性差异）
        expected = ms_dtype.dtype if hasattr(ms_dtype, 'dtype') else ms_dtype
        actual = result.dtype if hasattr(result, 'dtype') else result
        assert actual == expected

    # 测试未知 dtype 报错
    with pytest.raises(RuntimeError):
        t2ms_dtype(torch.complex32)  # PyTorch 无此类型，仅用于测试报错

def test_ms2t_dtype_function():
    """测试 ms2t_dtype 函数的 dtype 转换正确性"""
    # 测试常见 dtype
    for torch_dtype, ms_dtype in COMMON_DTYPE_PAIRS:
        ms_key = ms_dtype.dtype if hasattr(ms_dtype, 'dtype') else ms_dtype
        assert ms2t_dtype(ms_key) == torch_dtype

    # 测试不精确映射 dtype
    for ms_dtype, torch_dtype in IMPRECISE_DTYPE_PAIRS:
        assert ms2t_dtype(ms_dtype) == torch_dtype

    # 测试未知 dtype 报错
    with pytest.raises(RuntimeError):
        ms2t_dtype(ms.float64)  # 故意传入错误格式（实际应为 ms.float64.dtype）

def test_t2ms_basic_conversion():
    """测试 t2ms 基础张量转换（含连续性、稠密性处理）"""
    # 测试非连续张量
    torch_tensor = torch.tensor([[1, 2], [3, 4]], dtype=torch.float32)[::2, ::2]
    assert not torch_tensor.is_contiguous()
    ms_tensor = t2ms(torch_tensor)
    assert isinstance(ms_tensor, ms.Tensor)
    np.testing.assert_allclose(ms_tensor.asnumpy(), torch_tensor.numpy())

    # 测试稀疏张量转稠密
    if hasattr(torch, 'sparse_coo_tensor'):
        indices = torch.tensor([[0, 1], [2, 3]])
        values = torch.tensor([1.0, 2.0], dtype=torch.float32)
        sparse_torch = torch.sparse_coo_tensor(indices, values, (4, 4))
        ms_dense = t2ms(sparse_torch)
        assert ms_dense.shape == (4, 4)
        np.testing.assert_allclose(ms_dense.asnumpy(), sparse_torch.to_dense().numpy())

def test_t2ms_unsupported_dtype():
    """测试 t2ms 对 NumPy 不支持 dtype 的转换"""
    for torch_dtype, ms_dtype in UNSUPPORTED_DTYPE_PAIRS:
        # 构造 PyTorch 张量（bfloat16 需 PyTorch 1.10+ 支持）
        torch_tensor = torch.tensor([1.0, 2.0, 3.0], dtype=torch_dtype)
        ms_tensor = t2ms(torch_tensor)
        assert ms_tensor.dtype == ms_dtype
        # 精度允许范围内比较（float8 类型精度较低，放宽误差）
        if 'float8' in str(torch_dtype):
            np.testing.assert_allclose(
                ms_tensor.asnumpy().astype(np.float32),
                torch_tensor.numpy().astype(np.float32),
                rtol=1e-2
            )
        else:
            np.testing.assert_allclose(
                ms_tensor.asnumpy().astype(np.float32),
                torch_tensor.numpy().astype(np.float32),
                rtol=1e-5
            )

def test_ms2t_basic_conversion():
    """测试 ms2t 基础张量转换"""
    # 测试普通 dtype
    ms_tensor = ms.tensor([[5, 6], [7, 8]], dtype=ms.int64)
    torch_tensor = ms2t(ms_tensor)
    assert isinstance(torch_tensor, torch.Tensor)
    np.testing.assert_allclose(torch_tensor.numpy(), ms_tensor.asnumpy())

    # 测试布尔类型
    ms_bool = ms.tensor([True, False, True], dtype=ms.bool_)
    torch_bool = ms2t(ms_bool)
    assert torch_bool.dtype == torch.bool
    np.testing.assert_allclose(torch_bool.numpy(), ms_bool.asnumpy())

def test_ms2t_unsupported_dtype():
    """测试 ms2t 对特殊 dtype 的转换（如 bfloat16）"""
    ms_bf16 = ms.tensor([1.0, 2.0, 3.0], dtype=ms.bfloat16)
    torch_bf16 = ms2t(ms_bf16)
    assert torch_bf16.dtype == torch.bfloat16
    np.testing.assert_allclose(
        torch_bf16.numpy().astype(np.float32),
        ms_bf16.asnumpy().astype(np.float32),
        rtol=1e-5
    )

def test_imprecise_dtype_mapping():
    """测试不精确 dtype 映射（ms.int4/uint4 转 PyTorch）"""
    # 测试 ms.int4 -> torch.int8
    ms_int4 = ms.tensor([1, 2, 3], dtype=ms.int4)
    torch_int8 = ms2t(ms_int4)
    assert torch_int8.dtype == torch.int8
    np.testing.assert_allclose(torch_int8.numpy(), ms_int4.asnumpy())

    # 测试 ms.uint4 -> torch.uint8
    ms_uint4 = ms.tensor([10, 15, 0], dtype=ms.uint4)
    torch_uint8 = ms2t(ms_uint4)
    assert torch_uint8.dtype == torch.uint8
    np.testing.assert_allclose(torch_uint8.numpy(), ms_uint4.asnumpy())

def test_dlpack_conversion_fallback():
    """测试 DLPack 转换失败时的 NumPy 中转降级逻辑"""
    # 构造一个可能导致 DLPack 转换失败的张量（如复数类型，根据环境适配）
    torch_complex = torch.tensor([1+2j, 3+4j], dtype=torch.complex64)
    # 强制禁用 DLPack 测试降级逻辑
    ms_complex = t2ms(torch_complex, use_dlpack=False)
    assert isinstance(ms_complex, ms.Tensor)
    assert ms_complex.dtype == ms.complex64
    np.testing.assert_allclose(ms_complex.asnumpy(), torch_complex.numpy())

    # 反向测试 ms2t 降级逻辑
    ms_complex = ms.tensor([5+6j, 7+8j], dtype=ms.complex128)
    torch_complex = ms2t(ms_complex, use_dlpack=False)
    assert isinstance(torch_complex, torch.Tensor)
    assert torch_complex.dtype == torch.complex128
    np.testing.assert_allclose(torch_complex.numpy(), ms_complex.asnumpy())

if __name__ == "__main__":
    pytest.main([__file__, "-v"])